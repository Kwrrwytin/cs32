To run TunnelMan:

1. Locate the folder TunnelMan, which should have in it files named
IceMan and Assets.  It's likely that the path to the folder will be
/Users/yourname/TunnelMan or /Users/yourname/Downloads/TunnelMan.

2. Open a Terminal window and type
	cd whateverThePathIs
where you should replace whateverThePathIs with the path to the TunnelMan
folder.

3. Confirm you're in the right folder by typing
	ls
which should show you the Assets folder and the TunnelMan executable.

4. Type
	./TunnelMan
to play the game.  Use the arrow keys to move the space bar to squirt, and
the space bar to drop a gold nugget.  You can type q to quit the game
prematurely.

Alternatively, in the folder TunnelMan, you can move the Assets folder
to your home directory, then double-click on the TunnelMan executable
file.
